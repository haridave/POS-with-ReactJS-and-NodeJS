# Real-time-pos-system
A  Real-time Point of Sale system written in Node.js &amp; React.js
